import type {IToolbarItem} from "@shared/lib/text_editor/toolbar/interface";
import {ICON_PATHS} from "@shared/enum/icons";

const defaultToolbarItems: IToolbarItem[] = [
    { id: 'undo', type: 'action', itemType: 'button', title: 'Отменить', action: 'undo', icon: ICON_PATHS.UNDO, size: 'small' },
    { id: 'redo', type: 'action', itemType: 'button', title: 'Повторить', action: 'redo', icon: ICON_PATHS.REDO, size: 'small' },
    { id: 'divider1', type: 'divider', label: '' },
    //{
    //    id: 'blocks',
    //    type: 'block',
    //    label: 'Добавить',
    //    icon: '📝',
    //    children: [
            { id: 'paragraph', type: 'block', itemType: 'button', label: 'Текст', blockType: 'paragraph', icon: ICON_PATHS.FORMAT_PARAGRAPH },
            { id: 'heading', type: 'block', itemType: 'button', label: 'Заголовок', blockType: 'heading', icon: ICON_PATHS.FORMAT_HEADER_1 },
            { id: 'list', type: 'block', itemType: 'button', label: 'Список', blockType: 'list', icon: ICON_PATHS.FORMAT_LIST_UNNUMBERED },
            { id: 'code', type: 'block', itemType: 'button', label: 'Код', blockType: 'code', icon: ICON_PATHS.FORMAT_CODE },
            { id: 'quote', type: 'block', itemType: 'button', label: 'Цитата', blockType: 'quote', icon: ICON_PATHS.FORMAT_QUOTE },
            { id: 'table', type: 'block', itemType: 'button', label: 'Таблица', blockType: 'table', icon: ICON_PATHS.FORMAT_TABLE },
            { id: 'divider-block', type: 'block', itemType: 'button', label: 'Разделитель', blockType: 'divider', icon: ICON_PATHS.FORMAT_DIVIDER },
    //    ]
    //},
    { id: 'divider2', type: 'divider'},
    { id: 'bold', type: 'format', itemType: 'button', label: 'Жирный', action: 'bold', icon: ICON_PATHS.FORMAT_BOLD },
    { id: 'italic', type: 'format', itemType: 'button', label: 'Курсив', action: 'italic', icon: ICON_PATHS.FORMAT_ITALIC },
    { id: 'underline', type: 'format', itemType: 'button', label: 'Подчеркивание', action: 'underline', icon: ICON_PATHS.FORMAT_UNDERLINE },
    { id: 'align-left', type: 'format', itemType: 'button', label: 'По левому краю', action: 'justifyLeft', icon: ICON_PATHS.FORMAT_ALIGN_LEFT },
    { id: 'align-center', type: 'format', itemType: 'button', label: 'По центру', action: 'justifyCenter', icon: ICON_PATHS.FORMAT_ALIGN_CENTER },
    { id: 'align-right', type: 'format', itemType: 'button', label: 'По правому краю', action: 'justifyRight', icon: ICON_PATHS.FORMAT_ALIGN_RIGHT },
    //{ id: 'divider3', type: 'divider', label: '' },
    //{
    //    id: 'actions',
    //    type: 'action',
    //    label: 'Действия',
    //    icon: '⚙️',
    //    children: [
    //        { id: 'export', type: 'action', label: 'Экспорт', action: 'export', icon: '📤' },
    //        { id: 'clear', type: 'action', label: 'Очистить', action: 'clear', icon: '🗑️' },
    //        { id: 'duplicate', type: 'action', label: 'Дублировать', action: 'duplicate', icon: '⎘' }
    //    ]
    //}
];

export {defaultToolbarItems}