import type {IBlock} from "@shared/lib/text_editor/interface";
import React from "react";

interface IBlockProps {
    block: IBlock;
    isFocused: boolean;
    onUpdate: (content: string) => void;
    onKeyDown: (e: React.KeyboardEvent) => void;
}

export type {IBlockProps};