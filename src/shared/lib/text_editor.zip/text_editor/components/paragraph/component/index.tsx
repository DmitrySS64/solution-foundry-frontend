import type {FC} from "react";
import type {IBlockProps} from "..";
import {cn} from "@shared/ui/lib/cn";


const ParagraphBlock: FC<IBlockProps> = ({
    block,
    isFocused,
    onUpdate,
    onKeyDown
}) => {
    return (
        <div
            contentEditable
            suppressContentEditableWarning
            onBlur={(e) => onUpdate(e.currentTarget.textContent || '')}
            onKeyDown={onKeyDown}
            className={cn(
                "w-full min-h-[1.5em] rounded-md px-3 py-2 outline-none transition",
                isFocused
                    ? "border border-blue-500 bg-gray-50"
                    : "border border-transparent"
            )}
        >
            {block.content}
        </div>
    )
}

export {ParagraphBlock};