import React from 'react';
import type {IBlock} from "@shared/lib/text_editor/interface";

interface HeadingBlockProps {
    block: IBlock;
    isFocused: boolean;
    onUpdate: (content: string) => void;
    onKeyDown: (e: React.KeyboardEvent) => void;
}

const HeadingBlock: React.FC<HeadingBlockProps> = ({
                                                       block,
                                                       isFocused,
                                                       onUpdate,
                                                       onKeyDown
                                                   }) => {
    return (
        <h1
            contentEditable
            suppressContentEditableWarning
            onBlur={(e) => onUpdate(e.currentTarget.textContent || '')}
            onKeyDown={onKeyDown}
            className={'' +
                ''}
            style={{
                outline: 'none',
                minHeight: '1.5em',
                padding: '8px 12px',
                border: isFocused ? '1px solid #007bff' : '1px solid transparent',
                borderRadius: '4px',
                backgroundColor: isFocused ? '#f8f9fa' : 'transparent',
                margin: 0
            }}
        >
            {block.content}
        </h1>
    );
};

export default HeadingBlock;