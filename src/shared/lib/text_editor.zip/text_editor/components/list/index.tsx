import React from 'react';
import type {IBlock} from "@shared/lib/text_editor/interface";

interface ListBlockProps {
    block: IBlock;
    isFocused: boolean;
    onUpdate: (content: string) => void;
    onKeyDown: (e: React.KeyboardEvent) => void;
    blockRef: React.MutableRefObject<{ [key: string]: HTMLDivElement | null }>;
}

const ListBlock: React.FC<ListBlockProps> = ({
                                                 block,
                                                 isFocused,
                                                 onUpdate,
                                                 onKeyDown,
                                                 blockRef
                                             }) => {
    return (
        <div style={{ display: 'flex', alignItems: 'flex-start' }}>
      <span style={{
          marginRight: '12px',
          marginTop: '8px',
          fontSize: '16px',
          color: '#666'
      }}>•</span>
            <div
                ref={(el) => {
                    blockRef.current[block.id] = el;
                }}
                contentEditable
                suppressContentEditableWarning
                onBlur={(e) => onUpdate(e.currentTarget.textContent || '')}
                onKeyDown={onKeyDown}
                style={{
                    outline: 'none',
                    minHeight: '1.5em',
                    padding: '8px 12px',
                    border: isFocused ? '2px solid #007bff' : '1px solid transparent',
                    borderRadius: '4px',
                    backgroundColor: isFocused ? '#f8f9fa' : 'transparent',
                    flex: 1,
                    transition: 'all 0.2s ease'
                }}
                dangerouslySetInnerHTML={{ __html: block.content }}
            />
        </div>
    );
};

export default ListBlock;