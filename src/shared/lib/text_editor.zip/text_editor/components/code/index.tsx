import React from 'react';
import type {IBlock} from "@shared/lib/text_editor/interface";

interface CodeBlockProps {
    block: IBlock;
    isFocused: boolean;
    onUpdate: (content: string) => void;
    onKeyDown: (e: React.KeyboardEvent) => void;
}

const CodeBlock: React.FC<CodeBlockProps> = ({
                                                 block,
                                                 isFocused,
                                                 onUpdate,
                                                 onKeyDown
                                             }) => {
    return (
        <pre
            className="whitespace-pre-wrap bg-zinc-900 dark:bg-zinc-950 rounded-lg p-4 font-mono text-sm w-full h-fit outline-none resize-none bg-transparent text-green-400"
        >
            <code
                contentEditable
                suppressContentEditableWarning
                onBlur={(e) => onUpdate(e.currentTarget.textContent || '')}
                onKeyDown={onKeyDown}
                className="rounded-lg font-mono text-sm w-full h-fit outline-none resize-none bg-transparent text-green-400"
                aria-placeholder={'//Код'}
            >
                {block.content}
            </code>
        </pre>

    );
};

export default CodeBlock;